from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.helpers import utc_now


class ReportModal(discord.ui.Modal, title='Report a Player'):
    user = discord.ui.TextInput(label='Who are you reporting?', placeholder='Username / Discord mention / Roblox name')
    reason = discord.ui.TextInput(label='What happened?', style=discord.TextStyle.paragraph)

    def __init__(self, cog: 'Reports') -> None:
        super().__init__()
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction) -> None:
        channel_id = self.cog.bot.config.get('log_channels', {}).get('reports')
        channel = self.cog.bot.get_channel(channel_id) if channel_id else None
        if not channel:
            await interaction.response.send_message('Report channel is not configured.', ephemeral=True)
            return
        embed = discord.Embed(title='New Player Report', color=discord.Color.red(), timestamp=utc_now())
        embed.add_field(name='Reporter', value=f'{interaction.user.mention} ({interaction.user.id})', inline=False)
        embed.add_field(name='Reported User', value=str(self.user), inline=False)
        embed.add_field(name='Reason', value=str(self.reason), inline=False)
        await channel.send(embed=embed)
        await interaction.response.send_message('Your report has been sent to staff.', ephemeral=True)


class ReportView(discord.ui.View):
    def __init__(self, cog: 'Reports') -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label='Report Player', style=discord.ButtonStyle.danger, custom_id='openville_report_button')
    async def report(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(ReportModal(self.cog))


class Reports(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        bot.add_view(ReportView(self))

    @app_commands.command(name='report', description='Report a player to staff.')
    async def report(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(ReportModal(self))

    @app_commands.command(name='report_panel', description='Send the report button panel.')
    async def report_panel(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None) -> None:
        target = channel or interaction.channel
        embed = discord.Embed(title='Need help?', description='Press the button below to report a player to staff.', color=discord.Color.red())
        await target.send(embed=embed, view=ReportView(self))
        await interaction.response.send_message('Report panel sent.', ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Reports(bot))
