from __future__ import annotations

import discord
from discord.ext import commands


class RulesView(discord.ui.View):
    def __init__(self, rules_url: str) -> None:
        super().__init__(timeout=None)
        if rules_url:
            self.add_item(discord.ui.Button(label='View Rules', url=rules_url, style=discord.ButtonStyle.link))


class Welcome(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        config = self.bot.config.get('welcome', {})
        if not config.get('enabled', True):
            return

        channel_id = config.get('channel_id')
        channel = self.bot.get_channel(channel_id) if channel_id else None
        if not channel:
            return

        default_role_id = self.bot.config.get('default_role_id')
        if default_role_id:
            role = member.guild.get_role(default_role_id)
            if role:
                try:
                    await member.add_roles(role, reason='OpenVille default role on join')
                except discord.Forbidden:
                    pass

        text = config.get('message', 'Welcome, {mention}!').format(mention=member.mention, user=member)
        embed = discord.Embed(
            title='Welcome to OpenVille',
            description='Please verify to access the server and take a moment to review the rules.',
            color=discord.Color.blurple(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        await channel.send(content=text, embed=embed, view=RulesView(config.get('rules_url', '')))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Welcome(bot))
