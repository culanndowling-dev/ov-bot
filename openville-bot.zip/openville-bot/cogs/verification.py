from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import staff_only


class VerifyView(discord.ui.View):
    def __init__(self, bot: commands.Bot) -> None:
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label='Verify', style=discord.ButtonStyle.success, custom_id='openville_verify_button')
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            return

        role_id = self.bot.config.get('verified_role_id')
        role = interaction.guild.get_role(role_id) if role_id else None
        if not role:
            await interaction.response.send_message('Verified role is not configured yet.', ephemeral=True)
            return

        await interaction.user.add_roles(role, reason='User completed verification')
        await interaction.response.send_message('You are now verified. Welcome to OpenVille!', ephemeral=True)


class Verification(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        bot.add_view(VerifyView(bot))

    @app_commands.command(name='setup_verification', description='Send the verification panel.')
    @staff_only()
    async def setup_verification(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None) -> None:
        target = channel or interaction.channel
        embed = discord.Embed(
            title='OpenVille Verification',
            description='Press the button below to verify and gain access to the server.',
            color=discord.Color.green(),
        )
        await target.send(embed=embed, view=VerifyView(self.bot))
        await interaction.response.send_message(f'Verification panel sent to {target.mention}.', ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Verification(bot))
