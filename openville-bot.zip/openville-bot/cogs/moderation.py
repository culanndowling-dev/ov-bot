from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import staff_only
from utils.helpers import utc_now
from utils.json_store import load_json, save_json
from utils.logger import send_log


class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.warn_path = bot.base_dir / 'data' / 'warnings.json'
        self.warnings = load_json(self.warn_path, {})

    def add_warning(self, guild_id: int, user_id: int, reason: str, moderator_id: int) -> int:
        g = self.warnings.setdefault(str(guild_id), {})
        u = g.setdefault(str(user_id), [])
        u.append({'reason': reason, 'moderator_id': moderator_id, 'timestamp': utc_now().isoformat()})
        save_json(self.warn_path, self.warnings)
        return len(u)

    async def log_action(self, title: str, description: str) -> None:
        embed = discord.Embed(title=title, description=description, color=discord.Color.orange(), timestamp=utc_now())
        await send_log(self.bot, 'moderation', embed)

    async def handle_warn_threshold(self, member: discord.Member, warning_count: int, reason: str) -> str | None:
        thresholds = self.bot.config.get('moderation', {}).get('warn_thresholds', {})
        action = thresholds.get(str(warning_count))
        if not action:
            return None

        if action == 'mute':
            muted_role = member.guild.get_role(self.bot.config.get('muted_role_id'))
            if muted_role:
                await member.add_roles(muted_role, reason=f'Auto mute after {warning_count} warnings')
        elif action == 'kick':
            await member.kick(reason=f'Auto kick after {warning_count} warnings: {reason}')
        elif action == 'ban':
            await member.ban(reason=f'Auto ban after {warning_count} warnings: {reason}')
        return action

    @app_commands.command(name='warn', description='Warn a member.')
    @staff_only()
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        count = self.add_warning(interaction.guild.id, member.id, reason, interaction.user.id)
        auto_action = await self.handle_warn_threshold(member, count, reason)
        await self.log_action('Member Warned', f'{member.mention} warned by {interaction.user.mention}\nReason: {reason}\nTotal warnings: {count}')
        extra = f' Automatic action: **{auto_action}**.' if auto_action else ''
        await interaction.response.send_message(f'{member.mention} has been warned. Total warnings: **{count}**.{extra}', ephemeral=False)

    @app_commands.command(name='ban', description='Ban a member.')
    @staff_only()
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        await member.ban(reason=reason)
        await self.log_action('Member Banned', f'{member} was banned by {interaction.user}.\nReason: {reason}')
        await interaction.response.send_message(f'Banned {member}.')

    @app_commands.command(name='kick', description='Kick a member.')
    @staff_only()
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        await member.kick(reason=reason)
        await self.log_action('Member Kicked', f'{member} was kicked by {interaction.user}.\nReason: {reason}')
        await interaction.response.send_message(f'Kicked {member}.')

    @app_commands.command(name='mute', description='Mute a member by giving the muted role.')
    @staff_only()
    async def mute(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        role = interaction.guild.get_role(self.bot.config.get('muted_role_id'))
        if not role:
            await interaction.response.send_message('Muted role is not configured.', ephemeral=True)
            return
        await member.add_roles(role, reason=reason)
        await self.log_action('Member Muted', f'{member} was muted by {interaction.user}.\nReason: {reason}')
        await interaction.response.send_message(f'Muted {member}.')

    @app_commands.command(name='unmute', description='Remove the muted role from a member.')
    @staff_only()
    async def unmute(self, interaction: discord.Interaction, member: discord.Member) -> None:
        role = interaction.guild.get_role(self.bot.config.get('muted_role_id'))
        if not role:
            await interaction.response.send_message('Muted role is not configured.', ephemeral=True)
            return
        await member.remove_roles(role, reason=f'Unmuted by {interaction.user}')
        await self.log_action('Member Unmuted', f'{member} was unmuted by {interaction.user}.')
        await interaction.response.send_message(f'Unmuted {member}.')

    @app_commands.command(name='clear', description='Delete a number of recent messages.')
    @staff_only()
    async def clear(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]) -> None:
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await self.log_action('Messages Cleared', f'{interaction.user} cleared {len(deleted)} messages in {interaction.channel.mention}.')
        await interaction.followup.send(f'Deleted {len(deleted)} messages.', ephemeral=True)

    @app_commands.command(name='warnings', description='View warnings for a member.')
    @staff_only()
    async def warnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        data = self.warnings.get(str(interaction.guild.id), {}).get(str(member.id), [])
        if not data:
            await interaction.response.send_message(f'{member.mention} has no warnings.', ephemeral=True)
            return
        lines = [f"{index}. {entry['reason']}" for index, entry in enumerate(data, start=1)]
        embed = discord.Embed(title=f'Warnings for {member}', description='\n'.join(lines), color=discord.Color.yellow())
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Moderation(bot))
