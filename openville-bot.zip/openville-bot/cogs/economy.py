from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands

from utils.json_store import load_json, save_json


class Economy(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.path = bot.base_dir / 'economy.json'
        self.data = load_json(self.path, {'users': {}})

    def save(self) -> None:
        save_json(self.path, self.data)

    def get_user(self, user_id: int) -> dict:
        users = self.data.setdefault('users', {})
        return users.setdefault(str(user_id), {'balance': self.bot.config.get('economy', {}).get('starting_balance', 500), 'last_daily': None})

    @app_commands.command(name='balance', description='View your balance or another user balance.')
    async def balance(self, interaction: discord.Interaction, member: discord.Member | None = None) -> None:
        target = member or interaction.user
        user_data = self.get_user(target.id)
        await interaction.response.send_message(f'{target.mention} has **${user_data["balance"]}**.')

    @app_commands.command(name='daily', description='Claim your daily reward.')
    async def daily(self, interaction: discord.Interaction) -> None:
        user_data = self.get_user(interaction.user.id)
        now = datetime.now(timezone.utc)
        last_daily = datetime.fromisoformat(user_data['last_daily']) if user_data['last_daily'] else None
        if last_daily and now - last_daily < timedelta(days=1):
            remaining = timedelta(days=1) - (now - last_daily)
            hours = int(remaining.total_seconds() // 3600)
            await interaction.response.send_message(f'You already claimed daily. Try again in about {hours}h.', ephemeral=True)
            return
        amount = self.bot.config.get('economy', {}).get('daily_amount', 250)
        user_data['balance'] += amount
        user_data['last_daily'] = now.isoformat()
        self.save()
        await interaction.response.send_message(f'You claimed **${amount}**. New balance: **${user_data["balance"]}**.')

    @app_commands.command(name='work', description='Do a quick job for money.')
    async def work(self, interaction: discord.Interaction) -> None:
        user_data = self.get_user(interaction.user.id)
        econ = self.bot.config.get('economy', {})
        amount = random.randint(econ.get('work_min', 100), econ.get('work_max', 300))
        user_data['balance'] += amount
        self.save()
        await interaction.response.send_message(f'You worked a shift and earned **${amount}**. Balance: **${user_data["balance"]}**.')

    @app_commands.command(name='pay', description='Pay another player.')
    async def pay(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 100000]) -> None:
        sender = self.get_user(interaction.user.id)
        receiver = self.get_user(member.id)
        if sender['balance'] < amount:
            await interaction.response.send_message('You do not have enough money.', ephemeral=True)
            return
        sender['balance'] -= amount
        receiver['balance'] += amount
        self.save()
        await interaction.response.send_message(f'Paid **${amount}** to {member.mention}.')


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Economy(bot))
