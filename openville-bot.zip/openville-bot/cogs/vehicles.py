from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import is_staff, staff_only
from utils.helpers import utc_now
from utils.json_store import load_json, save_json
from utils.logger import send_log


class VehicleRegistrationModal(discord.ui.Modal, title='Register Vehicle'):
    make = discord.ui.TextInput(label='Make', placeholder='BMW')
    model = discord.ui.TextInput(label='Model', placeholder='M3')
    year = discord.ui.TextInput(label='Year', placeholder='2020')
    notes = discord.ui.TextInput(label='Notes', style=discord.TextStyle.paragraph, required=False)

    def __init__(self, cog: 'Vehicles') -> None:
        super().__init__()
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction) -> None:
        vehicles = self.cog.vehicles
        approved_models = vehicles.get('approved_models', [])
        is_mass_produced = any(
            v['make'].lower() == str(self.make).lower()
            and v['model'].lower() == str(self.model).lower()
            for v in approved_models
        )

        entry = {
            'user_id': interaction.user.id,
            'make': str(self.make),
            'model': str(self.model),
            'year': str(self.year),
            'notes': str(self.notes),
            'mass_produced_match': is_mass_produced,
            'status': 'pending',
            'submitted_at': utc_now().isoformat(),
        }
        vehicles.setdefault('pending', []).append(entry)
        self.cog.save()

        log_channel_id = self.cog.bot.config.get('log_channels', {}).get('vehicles')
        log_channel = self.cog.bot.get_channel(log_channel_id) if log_channel_id else None
        if log_channel:
            embed = self.cog.build_vehicle_embed(entry, interaction.user)
            await log_channel.send(embed=embed, view=VehicleApprovalView(self.cog, entry))

        await interaction.response.send_message('Your vehicle registration was submitted for staff review.', ephemeral=True)


class VehicleApprovalView(discord.ui.View):
    def __init__(self, cog: 'Vehicles', entry: dict) -> None:
        super().__init__(timeout=None)
        self.cog = cog
        self.entry = entry

    @discord.ui.button(label='Approve Vehicle', style=discord.ButtonStyle.success)
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not is_staff(interaction):
            await interaction.response.send_message('Staff only.', ephemeral=True)
            return
        self.entry['status'] = 'approved'
        self.entry['reviewed_by'] = interaction.user.id
        registry = self.cog.vehicles.setdefault('user_registry', {})
        registry.setdefault(str(self.entry['user_id']), []).append(self.entry)
        self.cog.vehicles['pending'] = [e for e in self.cog.vehicles.get('pending', []) if e is not self.entry]
        self.cog.save()
        embed = discord.Embed(title='Vehicle Approved', description=f"{self.entry['year']} {self.entry['make']} {self.entry['model']} approved.", color=discord.Color.green())
        await send_log(self.cog.bot, 'vehicles', embed)
        await interaction.response.edit_message(content='Vehicle approved.', view=None, embed=interaction.message.embeds[0])

    @discord.ui.button(label='Deny Vehicle', style=discord.ButtonStyle.danger)
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not is_staff(interaction):
            await interaction.response.send_message('Staff only.', ephemeral=True)
            return
        self.entry['status'] = 'denied'
        self.entry['reviewed_by'] = interaction.user.id
        self.cog.vehicles['pending'] = [e for e in self.cog.vehicles.get('pending', []) if e is not self.entry]
        self.cog.save()
        embed = discord.Embed(title='Vehicle Denied', description=f"{self.entry['year']} {self.entry['make']} {self.entry['model']} denied.", color=discord.Color.red())
        await send_log(self.cog.bot, 'vehicles', embed)
        await interaction.response.edit_message(content='Vehicle denied.', view=None, embed=interaction.message.embeds[0])


class RegisterVehicleButton(discord.ui.View):
    def __init__(self, cog: 'Vehicles') -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label='Register Vehicle', style=discord.ButtonStyle.primary, custom_id='openville_vehicle_register')
    async def register_vehicle(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(VehicleRegistrationModal(self.cog))


class Vehicles(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.path = bot.base_dir / 'vehicles.json'
        self.vehicles = load_json(self.path, {'approved_models': [], 'pending': [], 'user_registry': {}})
        bot.add_view(RegisterVehicleButton(self))

    def save(self) -> None:
        save_json(self.path, self.vehicles)

    def build_vehicle_embed(self, entry: dict, submitter: discord.abc.User) -> discord.Embed:
        embed = discord.Embed(title='Vehicle Registration Request', color=discord.Color.blurple(), timestamp=utc_now())
        embed.add_field(name='User', value=f'{submitter.mention} ({submitter.id})', inline=False)
        embed.add_field(name='Vehicle', value=f"{entry['year']} {entry['make']} {entry['model']}", inline=False)
        embed.add_field(name='Mass-produced match', value='Yes' if entry['mass_produced_match'] else 'No exact match in database', inline=False)
        if entry.get('notes'):
            embed.add_field(name='Notes', value=entry['notes'], inline=False)
        return embed

    @app_commands.command(name='register_vehicle', description='Open the vehicle registration form.')
    async def register_vehicle(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(VehicleRegistrationModal(self))

    @app_commands.command(name='check_vehicle', description='Check a user vehicle registry.')
    async def check_vehicle(self, interaction: discord.Interaction, member: discord.Member | None = None) -> None:
        target = member or interaction.user
        entries = self.vehicles.get('user_registry', {}).get(str(target.id), [])
        if not entries:
            await interaction.response.send_message(f'No approved vehicles found for {target.mention}.', ephemeral=True)
            return
        lines = [f"- {e['year']} {e['make']} {e['model']}" for e in entries]
        embed = discord.Embed(title=f'{target.display_name} Vehicle Registry', description='\n'.join(lines), color=discord.Color.blue())
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name='vehicle_panel', description='Send the vehicle registration button panel.')
    @staff_only()
    async def vehicle_panel(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None) -> None:
        target = channel or interaction.channel
        embed = discord.Embed(
            title='OpenVille Vehicle Registration',
            description='Press the button below to register a vehicle for staff review.',
            color=discord.Color.blurple(),
        )
        await target.send(embed=embed, view=RegisterVehicleButton(self))
        await interaction.response.send_message('Vehicle panel sent.', ephemeral=True)

    @app_commands.command(name='add_vehicle_model', description='Add a mass-produced vehicle model to the database.')
    @staff_only()
    async def add_vehicle_model(self, interaction: discord.Interaction, make: str, model: str, year: str) -> None:
        self.vehicles.setdefault('approved_models', []).append({'make': make, 'model': model, 'year': year, 'mass_produced': True})
        self.save()
        await interaction.response.send_message(f'Added {year} {make} {model} to vehicles.json.', ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Vehicles(bot))
