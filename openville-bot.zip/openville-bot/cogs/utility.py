from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands


class Utility(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name='ping', description='Check bot latency.')
    async def ping(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(f'Pong! `{round(self.bot.latency * 1000)}ms`')

    @app_commands.command(name='serverstats', description='Show server stats.')
    async def serverstats(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        embed = discord.Embed(title=f'{guild.name} Stats', color=discord.Color.blue())
        embed.add_field(name='Members', value=str(guild.member_count))
        embed.add_field(name='Channels', value=str(len(guild.channels)))
        embed.add_field(name='Roles', value=str(len(guild.roles)))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='userinfo', description='Show information about a user.')
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member | None = None) -> None:
        target = member or interaction.user
        embed = discord.Embed(title=f'User Info: {target}', color=discord.Color.blurple())
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name='ID', value=str(target.id), inline=False)
        embed.add_field(name='Joined Server', value=discord.utils.format_dt(target.joined_at, style='F') if target.joined_at else 'Unknown', inline=False)
        embed.add_field(name='Account Created', value=discord.utils.format_dt(target.created_at, style='F'), inline=False)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name='help', description='Show bot help.')
    async def help(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(title='OpenVille Bot Help', color=discord.Color.green())
        embed.description = (
            '`/ping`, `/serverstats`, `/userinfo`, `/daily`, `/work`, `/balance`, `/pay`, '
            '`/report`, `/suggest`, `/register_vehicle`, `/check_vehicle`, `/start_session`, `/end_session`, '
            '`/warn`, `/kick`, `/ban`, `/mute`, `/unmute`, `/clear`'
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Utility(bot))
