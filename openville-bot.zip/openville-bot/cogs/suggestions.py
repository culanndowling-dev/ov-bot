from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands


class Suggestions(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name='suggest', description='Post a server suggestion.')
    async def suggest(self, interaction: discord.Interaction, suggestion: str) -> None:
        channel_id = self.bot.config.get('suggestions', {}).get('channel_id')
        channel = self.bot.get_channel(channel_id) if channel_id else None
        if not channel:
            await interaction.response.send_message('Suggestion channel is not configured.', ephemeral=True)
            return
        embed = discord.Embed(title='New Suggestion', description=suggestion, color=discord.Color.gold())
        embed.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        message = await channel.send(embed=embed)
        await message.add_reaction('👍')
        await message.add_reaction('👎')
        await interaction.response.send_message('Suggestion posted.', ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Suggestions(bot))
