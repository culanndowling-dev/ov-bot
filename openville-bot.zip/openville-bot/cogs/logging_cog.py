from __future__ import annotations

import discord
from discord.ext import commands

from utils.helpers import utc_now
from utils.logger import send_log


class LoggingCog(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        embed = discord.Embed(title='Member Joined', color=discord.Color.green(), timestamp=utc_now())
        embed.add_field(name='User', value=f'{member} ({member.id})', inline=False)
        await send_log(self.bot, 'joins_leaves', embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        embed = discord.Embed(title='Member Left', color=discord.Color.red(), timestamp=utc_now())
        embed.add_field(name='User', value=f'{member} ({member.id})', inline=False)
        await send_log(self.bot, 'joins_leaves', embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(LoggingCog(bot))
