from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.checks import is_staff, staff_only
from utils.helpers import generate_session_code, utc_now
from utils.json_store import load_json, save_json
from utils.logger import send_log


class SessionControlView(discord.ui.View):
    def __init__(self, cog: 'Sessions') -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label='Start Session', style=discord.ButtonStyle.success, custom_id='openville_start_session')
    async def start_session_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not is_staff(interaction):
            await interaction.response.send_message('Staff only.', ephemeral=True)
            return
        await interaction.response.send_message('Use `/start_session` so you can choose the session type.', ephemeral=True)

    @discord.ui.button(label='End Session', style=discord.ButtonStyle.danger, custom_id='openville_end_session')
    async def end_session_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if not is_staff(interaction):
            await interaction.response.send_message('Staff only.', ephemeral=True)
            return
        await self.cog.end_active_session(interaction)


class Sessions(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.path = bot.base_dir / 'data' / 'sessions.json'
        self.data = load_json(self.path, {'active': None, 'history': []})
        bot.add_view(SessionControlView(self))

    def save(self) -> None:
        save_json(self.path, self.data)

    async def announce_session(self, interaction: discord.Interaction, session_type: str, code: str) -> None:
        ping_role = interaction.guild.get_role(self.bot.config.get('session_ping_role_id'))
        embed = discord.Embed(
            title='OPENVILLE RP SESSION',
            description=f'**Session Type:** {session_type}\n**Server Code:** {code}\n**Host:** {interaction.user.mention}',
            color=self.bot.config.get('sessions', {}).get('announcement_color', 3447003),
            timestamp=utc_now(),
        )
        await interaction.channel.send(content=ping_role.mention if ping_role else None, embed=embed)
        await send_log(self.bot, 'sessions', embed)

    async def end_active_session(self, interaction: discord.Interaction) -> None:
        active = self.data.get('active')
        if not active:
            await interaction.response.send_message('There is no active session right now.', ephemeral=True)
            return
        active['ended_at'] = utc_now().isoformat()
        self.data.setdefault('history', []).append(active)
        self.data['active'] = None
        self.save()
        await interaction.response.send_message(f"Session **{active['session_type']}** ended.")

    @app_commands.command(name='start_session', description='Start an RP session.')
    @staff_only()
    async def start_session(self, interaction: discord.Interaction, session_type: str) -> None:
        code = generate_session_code()
        active = {
            'session_type': session_type,
            'code': code,
            'host_id': interaction.user.id,
            'started_at': utc_now().isoformat(),
        }
        self.data['active'] = active
        self.save()
        await interaction.response.send_message(f'Session started with code **{code}**.', ephemeral=True)
        await self.announce_session(interaction, session_type, code)

    @app_commands.command(name='end_session', description='End the active RP session.')
    @staff_only()
    async def end_session(self, interaction: discord.Interaction) -> None:
        await self.end_active_session(interaction)

    @app_commands.command(name='session_panel', description='Send staff session buttons.')
    @staff_only()
    async def session_panel(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None) -> None:
        target = channel or interaction.channel
        embed = discord.Embed(title='Session Controls', description='Use the buttons below for quick staff actions.', color=discord.Color.blurple())
        await target.send(embed=embed, view=SessionControlView(self))
        await interaction.response.send_message('Session panel sent.', ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Sessions(bot))
