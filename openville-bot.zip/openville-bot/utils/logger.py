from __future__ import annotations

import discord


async def send_log(bot, category: str, embed: discord.Embed) -> None:
    channel_id = bot.config.get('log_channels', {}).get(category)
    if not channel_id:
        return

    channel = bot.get_channel(channel_id)
    if channel and isinstance(channel, discord.abc.Messageable):
        await channel.send(embed=embed)
