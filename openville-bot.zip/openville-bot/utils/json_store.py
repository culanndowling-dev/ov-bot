from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def ensure_file(path: str | Path, default: Any) -> Path:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    if not file_path.exists():
        with file_path.open('w', encoding='utf-8') as f:
            json.dump(default, f, indent=2)
    return file_path


def load_json(path: str | Path, default: Any) -> Any:
    file_path = ensure_file(path, default)
    with file_path.open('r', encoding='utf-8') as f:
        return json.load(f)


def save_json(path: str | Path, data: Any) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with file_path.open('w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
