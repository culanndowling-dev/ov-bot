from __future__ import annotations

import random
import string
from datetime import datetime, timezone


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def generate_session_code(length: int = 5) -> str:
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


def format_dt(dt: datetime | None) -> str:
    if dt is None:
        return 'Unknown'
    return dt.strftime('%Y-%m-%d %H:%M UTC')
