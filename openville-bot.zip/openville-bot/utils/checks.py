from __future__ import annotations

import discord
from discord import app_commands


def is_staff(interaction: discord.Interaction) -> bool:
    if not interaction.guild or not isinstance(interaction.user, discord.Member):
        return False

    staff_roles = interaction.client.config.get('staff_roles', [])
    if interaction.user.guild_permissions.administrator:
        return True
    return any(role.id in staff_roles for role in interaction.user.roles)


def staff_only() -> app_commands.check:
    async def predicate(interaction: discord.Interaction) -> bool:
        if not is_staff(interaction):
            raise app_commands.CheckFailure('You must be staff to use this command.')
        return True

    return app_commands.check(predicate)
